<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['nav_sendthread'] = "Lähetä keskustelu ystävälle";
$l['send_thread'] = "Lähetä ystävälle";
$l['recipient'] = "Vastaanottaja:";
$l['recipient_note'] = "Kirjoita ystäväsi sähköpostiosoite";
$l['subject'] = "Otsikko:";
$l['message'] = "Viesti:";
$l['error_nosubject'] = "Kirjoita otsikko, jotta viesti voidaan lähettää";
$l['error_nomessage'] = "Kirjoita viesti, jotta sähköposti voidaan lähettää";
?>