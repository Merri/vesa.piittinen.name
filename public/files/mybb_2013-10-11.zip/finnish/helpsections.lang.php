<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

/* Siirrä tämän tekstin lopussa olevat kaksi merkkiä sijaitsemaan tiedoston loppuun käyttääksesi tietokantaan tallennettua ohjeistusta näiden lokalisoitujen rivien sijasta */

// Help Section 1
$l['s1_name'] = "Tunnuksen hallinta";
$l['s1_desc'] = "Perusteet oman käyttäjätunnuksen hallintaan.";

// Help Section 2
$l['s2_name'] = "Viestien hallinta";
$l['s2_desc'] = "Kirjoittaminen, vastaaminen ja keskustelualueen peruskäyttö.";
?>