<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['report_post'] = "Ilmoita viestistä";
$l['report_to_mod'] = "Ilmoita viestistä ylläpidolle";
$l['only_report'] = "Viestistä kannattaa ilmoittaa vain, mikäli se on roskaposti, mainontaa tai palvelun väärinkäyttöä.";
$l['report_reason'] = "Perustelusi ilmoitukselle:";
$l['thank_you'] = "Kiitos.";
$l['post_reported'] = "Ilmoitus on tehty onnistuneesti. Voit sulkea ikkunan.";
$l['report_error'] = "Virhe";
$l['no_reason'] = "Ilmoitus vaatii perustelun.";
$l['go_back'] = "Takaisin";
$l['close_window'] = "Sulje ikkuna";
?>