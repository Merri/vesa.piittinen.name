<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['nav_showteam'] = "Vastuuhenkilöt";
$l['forum_team'] = "Ylläpito";
$l['moderators'] = "Valvojat";
$l['mod_username'] = "Tunnus";
$l['mod_forums'] = "Huoneet";
$l['mod_email'] = "Sähköposti";
$l['mod_pm'] = "Yksäri";
$l['uname'] = "Tunnus";
$l['email'] = "Sähköposti";
$l['pm'] = "Yksäri";
$l['group_leaders'] = "Ryhmän vetäjä";
$l['group_members'] = "Jäsenet";
$l['no_members'] = "Ryhmässä ei ole jäseniä";
$l['error_noteamstoshow'] = "Vastuuhenkilöitä ei voi näyttää, koska heitä ei ole";
?>