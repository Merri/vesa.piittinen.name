<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: customhelpdocs.lang.php 5016 2010-06-12 00:24:02Z RyanGordon $
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Document name";
 * $l['d{hid}_desc'] = "Document description";
 * $l['d{hid}_document'] = "Document text";
 */
?>