<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['nav_announcements'] = "Ilmoitus";
$l['announcements'] = "Ilmoitus";
$l['forum_announcement'] = "Huoneilmoitus: {1}";
$l['error_invalidannouncement'] = "Ilmoitus ei ole kelvollinen.";

$l['announcement_edit'] = "Muokkaa ilmoitusta";
$l['announcement_qdelete'] = "Poista ilmoitus";
$l['announcement_quickdelete_confirm'] = "Haluatko varmasti poistaa ilmoituksen?";

?>