<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['redirect_threadrated'] = "Kiitos arvostelusta, sinut ohjataan keskusteluun.";
$l['error_invalidrating'] = "Antamasi arvostelu ei ole kelvollinen tälle keskustelulle. Siirry takaisin ja yritä uudelleen.";
$l['error_alreadyratedthread'] = "Olet jo arvostellut tämän keskustelun.";
$l['rating_votes_average'] = "{1} ääntä – keskiarvo {2}/5";
$l['one_star'] = "1 / 5";
$l['two_stars'] = "2 / 5";
$l['three_stars'] = "3 / 5";
$l['four_stars'] = "4 / 5";
$l['five_stars'] = "5 / 5";
$l['rating_added'] = "Arvostelusi on huomioitu!";
?>