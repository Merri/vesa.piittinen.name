<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */
 
$l['error_no_connection'] = 'Virhe muodostaessa yhteyttä palvelimelle: ';
$l['error_no_message'] = 'Viestiä ei määritetty.';
$l['error_no_subject'] = 'Otsikkoa ei määritetty.';
$l['error_no_recipient'] = 'Vastaanottajaa ei määritetty.';
$l['error_not_sent'] = 'Tapahtui virhe käytettäessä PHP:n mail-funktiota.';
$l['error_status_missmatch'] = 'Palvelimen antama tila ei vastaa odotettua tulosta: ';
$l['error_data_not_sent'] = 'Tätä tietoa ei kyetty lähettämään palvelimelle: ';

$l['error_occurred'] = 'Ainakin yksi virhe on tapahtunut. Korjaa mainitut virheet ennen kuin jatkat.<br />';
?>