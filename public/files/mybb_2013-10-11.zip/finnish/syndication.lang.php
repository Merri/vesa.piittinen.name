<?php
/**
 * MyBB 1.6 Finnish Language Pack
 * Suomentanut Vesa Piittinen, katso http://community.mybb.com/thread-89482.html
 */

$l['all_forums'] = "Kaikki huoneet";
$l['forum'] = "Huone:";
$l['posted_by'] = "Kirjoitti:";
$l['on'] = "";
?>
